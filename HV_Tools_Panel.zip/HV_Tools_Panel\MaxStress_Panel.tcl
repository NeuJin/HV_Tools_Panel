# MaxStress_Panel.tcl — button panel ("add-in") for the Max Stress tools.
#
# Load inside HyperView:   source <path>/MaxStress_Panel.tcl
# Or auto-open at startup: hw.exe <model> -tcl <path>/MaxStress_Panel.tcl
#
# The panel is a floating always-on-top window. All logic lives in
# maxstress_lib.tcl; this file is UI only.

source [file join [file dirname [file normalize [info script]]] maxstress_lib.tcl]

package require Tk

namespace eval ::MaxStressPanel {
    variable W .maxstressPanel
    variable CONFIG [file join $::MaxStress::LIB_DIR "maxstress_config.txt"]
}

# ── Config persistence: model path, layout, result paths ──
proc ::MaxStressPanel::SaveConfig {modelFile cols rows resultFiles} {
    variable CONFIG
    catch {
        set f [open $CONFIG w]
        puts $f $modelFile
        puts $f "$cols $rows"
        foreach rf $resultFiles { puts $f $rf }
        close $f
    }
}

# Returns {modelFile cols rows resultFiles} or "" when no config saved yet
proc ::MaxStressPanel::LoadConfig {} {
    variable CONFIG
    if {![file exists $CONFIG]} { return "" }
    set f [open $CONFIG r]
    set lines {}
    while {[gets $f line] >= 0} {
        if {[string trim $line] ne ""} { lappend lines $line }
    }
    close $f
    if {[llength $lines] < 3} { return "" }
    set modelFile [lindex $lines 0]
    lassign [lindex $lines 1] cols rows
    set resultFiles [lrange $lines 2 end]
    return [list $modelFile $cols $rows $resultFiles]
}

proc ::MaxStressPanel::SetStatus {msg {color black}} {
    variable W
    $W.status configure -text $msg -foreground $color
    update idletasks
}

proc ::MaxStressPanel::BrowseModel {} {
    variable W
    set f [tk_getOpenFile -title "Select model file" \
        -filetypes {{"Model files" {.inp .fem .key .dyn}} {"All files" *}}]
    if {$f ne ""} {
        $W.load.model delete 0 end
        $W.load.model insert 0 $f
    }
}

proc ::MaxStressPanel::BrowseResults {} {
    variable W
    set files [tk_getOpenFile -title "Select result file(s)" -multiple 1 \
        -filetypes {{"Result files" {.odb .res .op2 .h3d}} {"All files" *}}]
    foreach f $files {
        $W.load.res insert end "$f\n"
    }
}

# Read the Load section fields -> {modelFile cols rows resultFiles}
proc ::MaxStressPanel::ReadLoadFields {} {
    variable W
    set modelFile [string trim [$W.load.model get]]
    set cols [string trim [$W.load.cols get]]
    set rows [string trim [$W.load.rows get]]
    set resultFiles {}
    foreach line [split [$W.load.res get 1.0 end] "\n"] {
        set line [string trim $line]
        if {$line ne ""} { lappend resultFiles $line }
    }
    return [list $modelFile $cols $rows $resultFiles]
}

proc ::MaxStressPanel::DoLoadAll {} {
    variable W
    lassign [ReadLoadFields] modelFile cols rows resultFiles
    if {$modelFile eq ""} {
        SetStatus "Enter the model file path first." red
        return
    }
    if {[llength $resultFiles] == 0} {
        SetStatus "Enter at least one result file path." red
        return
    }
    if {![string is integer -strict $cols] || ![string is integer -strict $rows]} {
        SetStatus "Layout must be two integers (e.g. 4 x 2)." red
        return
    }
    SetStatus "Loading [llength $resultFiles] result(s) into ${cols}x${rows} layout..." blue
    if {[catch {::MaxStress::LoadAll $modelFile $resultFiles $cols $rows} result]} {
        SetStatus "Load FAILED: $result" red
    } else {
        SaveConfig $modelFile $cols $rows $resultFiles
        SetStatus "Loaded [llength $resultFiles] result(s) into $result window(s)." darkgreen
    }
}

proc ::MaxStressPanel::DoExport {} {
    variable W
    set ids [split [string trim [$W.exp.ids get]]]
    if {[llength $ids] == 0} {
        SetStatus "Enter selection set IDs first." red
        return
    }
    SetStatus "Export running..." blue
    if {[catch {::MaxStress::RunExport $ids} result]} {
        SetStatus "Export FAILED: $result" red
    } else {
        LoadResults
        SetStatus "Export done -> $result" darkgreen
    }
}

# Fill the results table from Stress_Summary.csv
# (columns: WindowID,SetName,MaxNodeID,MaxStressValue_MPa,SimulationID,CrankAngle_deg,SimulationLabel)
proc ::MaxStressPanel::LoadResults {} {
    variable W
    set csvFile [file join $::MaxStress::LIB_DIR "Stress_Summary.csv"]

    $W.res.tv delete [$W.res.tv children {}]

    if {![file exists $csvFile]} {
        SetStatus "No CSV yet — run Export first." red
        return
    }
    set f [open $csvFile r]
    set lineNo 0
    set n 0
    while {[gets $f line] >= 0} {
        incr lineNo
        if {$lineNo == 1} { continue }
        if {[string trim $line] eq ""} { continue }
        set fields [split $line ","]
        if {[llength $fields] < 6} { continue }
        lassign $fields rWin rSetName rNodeID rStress rSimID rAngle
        set stress3 ""
        catch {set stress3 [format "%.3f" $rStress]}
        $W.res.tv insert {} end -values [list $rWin $rSetName $rNodeID $stress3 $rAngle]
        incr n
    }
    close $f
    SetStatus "Results table: $n row(s) loaded." darkgreen
}

proc ::MaxStressPanel::DoAnnotate {} {
    variable W
    set setID [string trim [$W.ann.id get]]
    if {$setID eq ""} {
        SetStatus "Enter one selection set ID first." red
        return
    }
    SetStatus "Annotating set $setID..." blue
    if {[catch {::MaxStress::RunAnnotate $setID} result]} {
        SetStatus "Annotate FAILED: $result" red
    } else {
        SetStatus "Annotate done (set $setID)." darkgreen
    }
}

# Row selected -> copy its Node ID + Angle into the edit fields
proc ::MaxStressPanel::OnSelect {} {
    variable W
    set sel [$W.res.tv selection]
    if {[llength $sel] == 0} { return }
    set vals [$W.res.tv item [lindex $sel 0] -values]
    lassign $vals rWin rSet rNode rStress rAngle
    $W.res.node delete 0 end ; $W.res.node insert 0 $rNode
    $W.res.ang  delete 0 end ; $W.res.ang  insert 0 $rAngle
}

# Re-query the stress value for the selected row using the edited
# Node ID + Angle, then update the table row and the CSV.
proc ::MaxStressPanel::DoRequery {} {
    variable W
    set sel [$W.res.tv selection]
    if {[llength $sel] == 0} {
        SetStatus "Select a row in the table first." red
        return
    }
    set item [lindex $sel 0]
    lassign [$W.res.tv item $item -values] rWin rSet oldNode oldStress oldAngle
    set newNode  [string trim [$W.res.node get]]
    set newAngle [string trim [$W.res.ang get]]
    if {$newNode eq "" || $newAngle eq ""} {
        SetStatus "Enter Node ID and Angle first." red
        return
    }
    SetStatus "Re-querying win $rWin node $newNode @ $newAngle ..." blue
    if {[catch {::MaxStress::QueryNodeValue $rWin $newNode $newAngle} result]} {
        SetStatus "Re-query FAILED: $result" red
        return
    }
    lassign $result val simIdx simLabel angleStr
    set stress3 [format "%.3f" $val]
    $W.res.tv item $item -values [list $rWin $rSet $newNode $stress3 $angleStr]
    UpdateCsvRow $rWin $rSet $newNode $val $simIdx $angleStr $simLabel
    SetStatus "Win $rWin / $rSet -> node $newNode @ $angleStr = $stress3 MPa (CSV updated)" darkgreen
}

# Rewrite the matching (WindowID,SetName) row in Stress_Summary.csv
proc ::MaxStressPanel::UpdateCsvRow {rWin rSet nodeID val simIdx angleStr simLabel} {
    set csvFile [file join $::MaxStress::LIB_DIR "Stress_Summary.csv"]
    if {![file exists $csvFile]} { return }
    set f [open $csvFile r]
    set lines {}
    while {[gets $f line] >= 0} { lappend lines $line }
    close $f

    set out {}
    foreach line $lines {
        set fields [split $line ","]
        if {[llength $fields] >= 6 && [lindex $fields 0] == $rWin && [lindex $fields 1] eq $rSet} {
            lappend out "$rWin,$rSet,$nodeID,[format "%.8f" $val],$simIdx,$angleStr,\"$simLabel\""
        } else {
            lappend out $line
        }
    }
    set f [open $csvFile w]
    foreach line $out { puts $f $line }
    close $f
}

proc ::MaxStressPanel::Build {} {
    variable W

    catch {destroy $W}
    toplevel $W
    wm title $W "Max Stress Tools — Nguyen Tan Loc"
    wm attributes $W -topmost 1
    wm resizable $W 0 1     ;# vertically resizable for the results table

    # ── Load section ──
    labelframe $W.load -text " 0. Load model && results " -padx 8 -pady 6
    label  $W.load.lm -text "Model file (shared by all windows):"
    entry  $W.load.model -width 46
    button $W.load.bm -text "..." -width 3 -command ::MaxStressPanel::BrowseModel
    label  $W.load.lr -text "Result files (one per line — one window each):"
    text   $W.load.res -width 46 -height 4 -yscrollcommand [list $W.load.rsb set]
    scrollbar $W.load.rsb -orient vertical -command [list $W.load.res yview]
    button $W.load.br -text "Add..." -width 6 -command ::MaxStressPanel::BrowseResults
    frame  $W.load.lay
    label  $W.load.lay.l -text "Layout:"
    entry  $W.load.cols -width 3
    label  $W.load.lay.x -text "x"
    entry  $W.load.rows -width 3
    label  $W.load.lay.hint -text "(ngang x doc)"
    button $W.load.run -text "Load All" -width 14 -command ::MaxStressPanel::DoLoadAll

    grid $W.load.lm    -row 0 -column 0 -columnspan 2 -sticky w
    grid $W.load.model -row 1 -column 0 -sticky we -pady 2
    grid $W.load.bm    -row 1 -column 1 -padx {4 0}
    grid $W.load.lr    -row 2 -column 0 -columnspan 2 -sticky w -pady {6 0}
    grid $W.load.res   -row 3 -column 0 -sticky we -pady 2
    grid $W.load.rsb   -row 3 -column 1 -sticky ns
    grid $W.load.br    -row 4 -column 0 -sticky w
    grid $W.load.lay   -row 5 -column 0 -sticky w -pady {6 0}
    pack $W.load.lay.l    -in $W.load.lay -side left
    pack $W.load.cols     -in $W.load.lay -side left -padx {4 2}
    pack $W.load.lay.x    -in $W.load.lay -side left
    pack $W.load.rows     -in $W.load.lay -side left -padx {2 4}
    pack $W.load.lay.hint -in $W.load.lay -side left
    pack $W.load.run      -in $W.load.lay -side left -padx {20 0}
    grid columnconfigure $W.load 0 -weight 1
    pack $W.load -fill x -padx 10 -pady {10 4}

    # Layout default 4 x 2
    $W.load.cols insert 0 "4"
    $W.load.rows insert 0 "2"

    # ── Export section ──
    labelframe $W.exp -text " 1. Max Stress Export (all windows) " -padx 8 -pady 6
    label  $W.exp.lbl -text "Selection set IDs (space-separated):"
    entry  $W.exp.ids -width 32
    button $W.exp.run -text "Run Export" -width 14 -command ::MaxStressPanel::DoExport
    grid $W.exp.lbl -row 0 -column 0 -sticky w
    grid $W.exp.ids -row 1 -column 0 -sticky we -pady 2
    grid $W.exp.run -row 1 -column 1 -padx {6 0}
    pack $W.exp -fill x -padx 10 -pady {10 4}

    # ── Annotate section ──
    labelframe $W.ann -text " 2. Annotate Max Stress (from CSV) " -padx 8 -pady 6
    label  $W.ann.lbl -text "One selection set ID:"
    entry  $W.ann.id -width 12
    button $W.ann.run -text "Annotate" -width 14 -command ::MaxStressPanel::DoAnnotate
    grid $W.ann.lbl -row 0 -column 0 -sticky w
    grid $W.ann.id  -row 1 -column 0 -sticky w -pady 2
    grid $W.ann.run -row 1 -column 1 -padx {6 0}
    pack $W.ann -fill x -padx 10 -pady 4

    # ── Options section ──
    labelframe $W.opt -text " Options " -padx 8 -pady 6
    label $W.opt.l1 -text "Marker size:"
    entry $W.opt.mea -width 5 -textvariable ::MaxStress::MEA_FSIZE
    label $W.opt.l2 -text "Note size:"
    entry $W.opt.note -width 5 -textvariable ::MaxStress::NOTE_FSIZE
    label $W.opt.l3 -text "Color (R G B):"
    entry $W.opt.color -width 12 -textvariable ::MaxStress::PINK
    grid $W.opt.l1    -row 0 -column 0 -sticky w
    grid $W.opt.mea   -row 0 -column 1 -sticky w -padx {4 12}
    grid $W.opt.l2    -row 0 -column 2 -sticky w
    grid $W.opt.note  -row 0 -column 3 -sticky w -padx {4 0}
    grid $W.opt.l3    -row 1 -column 0 -sticky w -pady {4 0}
    grid $W.opt.color -row 1 -column 1 -columnspan 3 -sticky w -padx {4 0} -pady {4 0}
    checkbutton $W.opt.shownote -text "Show note header" -variable ::MaxStress::SHOW_NOTE
    grid $W.opt.shownote -row 2 -column 0 -columnspan 3 -sticky w -pady {4 0}
    pack $W.opt -fill x -padx 10 -pady 4

    # ── Results table (all windows) ──
    labelframe $W.res -text " 3. Results — all windows " -padx 8 -pady 6
    ttk::treeview $W.res.tv -columns {win set node stress angle} -show headings -height 9 \
        -yscrollcommand [list $W.res.sb set]
    $W.res.tv heading win    -text "Win"
    $W.res.tv heading set    -text "Set"
    $W.res.tv heading node   -text "Node ID"
    $W.res.tv heading stress -text "Max Stress (MPa)"
    $W.res.tv heading angle  -text "Angle"
    $W.res.tv column win    -width 40  -anchor center
    $W.res.tv column set    -width 80  -anchor w
    $W.res.tv column node   -width 90  -anchor center
    $W.res.tv column stress -width 110 -anchor e
    $W.res.tv column angle  -width 90  -anchor center
    scrollbar $W.res.sb -orient vertical -command [list $W.res.tv yview]
    button $W.res.refresh -text "Refresh from CSV" -command ::MaxStressPanel::LoadResults

    # Edit row: pick a row, adjust Node ID / Angle, re-query the value
    frame $W.res.edit
    label  $W.res.edit.l1 -text "Node ID:"
    entry  $W.res.node -width 12
    label  $W.res.edit.l2 -text "Angle:"
    entry  $W.res.ang -width 12
    button $W.res.requery -text "Re-query Value" -command ::MaxStressPanel::DoRequery

    grid $W.res.tv      -row 0 -column 0 -sticky nswe
    grid $W.res.sb      -row 0 -column 1 -sticky ns
    grid $W.res.edit    -row 1 -column 0 -sticky w -pady {4 0}
    pack $W.res.edit.l1 -in $W.res.edit -side left
    pack $W.res.node    -in $W.res.edit -side left -padx {4 10}
    pack $W.res.edit.l2 -in $W.res.edit -side left
    pack $W.res.ang     -in $W.res.edit -side left -padx {4 10}
    pack $W.res.requery -in $W.res.edit -side left
    grid $W.res.refresh -row 2 -column 0 -sticky w -pady {4 0}
    grid columnconfigure $W.res 0 -weight 1
    pack $W.res -fill both -expand 1 -padx 10 -pady 4

    bind $W.res.tv <<TreeviewSelect>> ::MaxStressPanel::OnSelect

    # ── Status bar ──
    label $W.status -text "Ready." -anchor w -relief sunken -padx 6
    pack $W.status -fill x -side bottom -padx 10 -pady {4 10}

    # Pre-fill the table if a CSV from a previous run exists
    catch {LoadResults}

    # ── Auto-load on open ──
    # If a saved config exists (from the last "Load All"), prefill the Load
    # fields and run the load automatically so opening the panel restores
    # the whole multi-window session in one step.
    set cfg [LoadConfig]
    if {$cfg ne ""} {
        lassign $cfg modelFile cols rows resultFiles
        $W.load.model delete 0 end ; $W.load.model insert 0 $modelFile
        $W.load.cols  delete 0 end ; $W.load.cols  insert 0 $cols
        $W.load.rows  delete 0 end ; $W.load.rows  insert 0 $rows
        $W.load.res   delete 1.0 end
        foreach rf $resultFiles { $W.load.res insert end "$rf\n" }

        set missing 0
        if {![file exists $modelFile]} { set missing 1 }
        foreach rf $resultFiles { if {![file exists $rf]} { set missing 1 } }
        if {$missing} {
            SetStatus "Saved paths restored — some files missing, auto-load skipped." red
        } else {
            SetStatus "Auto-loading saved model & results..." blue
            after idle ::MaxStressPanel::DoLoadAll
        }
    }
}

::MaxStressPanel::Build
puts "Max Stress panel loaded — window '[wm title $::MaxStressPanel::W]' is open."
